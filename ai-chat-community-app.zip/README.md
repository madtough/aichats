# AI Chat + Group Messaging App

See setup instructions inside.